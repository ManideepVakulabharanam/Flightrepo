package com.cg.FlightManagement.exceptionHandler;

public class RouteNotFoundException extends RuntimeException {
    public RouteNotFoundException(String msg) {
    	super(msg);
    }
}