package com.cg.FlightManagement.exceptionHandler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
  
	//Exception handler to handle add flight, schedule, route
	@ExceptionHandler({CouldNotAddException.class})
    public ResponseEntity<Object> handleCouldnotAddException(CouldNotAddException exception) {
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(exception.getMessage());
    }
	//To Handle Delete Flight, schedule, route
	@ExceptionHandler({CouldNotFoundException.class})
    public ResponseEntity<Object> handleCouldNotFoundException(CouldNotFoundException exception) {
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(exception.getMessage());
    }
	//To Handle Empty Flights, routes, schedules
	@ExceptionHandler({NoDataFoundException.class})
	public ResponseEntity<Object> handleNoDataFound(NoDataFoundException exception) {
	    return ResponseEntity
	            .status(HttpStatus.INTERNAL_SERVER_ERROR)
	            .body(exception.getMessage());
	}
	
	//If user aleardy present
	@ExceptionHandler({UserAlreadyExistsException.class})
	public ResponseEntity<Object> handleUserAlreadyExists(UserAlreadyExistsException exception) {
	    return ResponseEntity
	            .status(HttpStatus.INTERNAL_SERVER_ERROR)
	            .body(exception.getMessage());
	}
	
	// if no user Found exception
	@ExceptionHandler({UserNotFoundException.class})
	public ResponseEntity<Object> handleUserNotFound(UserNotFoundException exception) {
	    return ResponseEntity
	            .status(HttpStatus.INTERNAL_SERVER_ERROR)
	            .body(exception.getMessage());
	}
	
}
