package com.cg.FlightManagement.exceptionHandler;

public class NoRoutesFoundException extends RuntimeException {
    public NoRoutesFoundException(String msg) {
    	super(msg);
    }
}