package com.cg.FlightManagement.exceptionHandler;

public class UserNotFoundToCancelBookingException extends RuntimeException {
    public UserNotFoundToCancelBookingException(String msg) {
    	super(msg);
    }
}