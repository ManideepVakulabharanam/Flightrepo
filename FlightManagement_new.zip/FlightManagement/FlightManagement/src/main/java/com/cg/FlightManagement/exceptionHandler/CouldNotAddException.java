package com.cg.FlightManagement.exceptionHandler;

public class CouldNotAddException extends RuntimeException {
    public CouldNotAddException(String msg) {
    	super(msg);
    }
}
