package com.cg.FlightManagement.exceptionHandler;

public class FlightNotFoundException extends RuntimeException {
    public FlightNotFoundException(String msg) {
    	super(msg);
    }
}