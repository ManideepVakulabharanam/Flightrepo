package com.cg.FlightManagement.exceptionHandler;

public class CouldNotFoundException extends RuntimeException {
    public CouldNotFoundException(String msg) {
    	super(msg);
    }
}
