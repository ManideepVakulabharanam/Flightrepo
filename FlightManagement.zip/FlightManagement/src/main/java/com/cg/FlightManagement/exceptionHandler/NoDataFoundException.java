package com.cg.FlightManagement.exceptionHandler;

public class NoDataFoundException extends RuntimeException {
    public NoDataFoundException(String msg) {
    	super(msg);
    }
}