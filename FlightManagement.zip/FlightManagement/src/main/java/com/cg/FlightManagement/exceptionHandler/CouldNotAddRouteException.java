package com.cg.FlightManagement.exceptionHandler;

public class CouldNotAddRouteException extends RuntimeException {
    public CouldNotAddRouteException(String msg) {
    	super(msg);
    }
}