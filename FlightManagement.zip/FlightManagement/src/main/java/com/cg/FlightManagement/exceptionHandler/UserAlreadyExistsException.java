package com.cg.FlightManagement.exceptionHandler;

public class UserAlreadyExistsException extends RuntimeException {
    public UserAlreadyExistsException(String msg) {
    	super(msg);
    }
}