package com.cg.FlightManagement.service;

import com.cg.FlightManagement.entity.*;
import com.cg.FlightManagement.exceptionHandler.CouldNotAddException;
import com.cg.FlightManagement.exceptionHandler.CouldNotFoundException;
import com.cg.FlightManagement.exceptionHandler.NoDataFoundException;
import com.cg.FlightManagement.repositories.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FlightService {
    @Autowired
    private FlightRepository flightRepository;

    public Flight addFlight(Flight flight) {
    	Long id = flight.getId();
    	Flight existingflight = flightRepository.findById(id).orElse(null);
    	if(existingflight == null) {
    		return flightRepository.save(flight);
    	}
    	else{
    		throw new CouldNotAddException("Could not Add Flight, Flight aleardy exsists");
    	}
    }

    public List<Flight> getAllFlights() {
        List<Flight> list =  flightRepository.findAll();
        if(list.size() == 0) {
        	throw new NoDataFoundException("No Flights were found.");
        }else {
        	return list;
        }
    }

    public void deleteFlight(Long id) {
    	Flight flight = flightRepository.findById(id).orElse(null);
    	if(flight != null) {
        flightRepository.deleteById(id);
    	}
    	else {
    		throw new CouldNotFoundException("We could not find the data by given ID. please enter valid ID");
    	}
    }
}
