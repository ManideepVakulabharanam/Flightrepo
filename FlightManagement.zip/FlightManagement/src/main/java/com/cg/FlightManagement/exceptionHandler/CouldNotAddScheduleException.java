package com.cg.FlightManagement.exceptionHandler;

public class CouldNotAddScheduleException extends RuntimeException {
    public CouldNotAddScheduleException(String msg) {
    	super(msg);
    }
}