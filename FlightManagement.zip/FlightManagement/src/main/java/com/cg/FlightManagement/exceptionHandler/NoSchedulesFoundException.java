package com.cg.FlightManagement.exceptionHandler;

public class NoSchedulesFoundException extends RuntimeException {
    public NoSchedulesFoundExceptionextends(String msg) {
    	super(msg);
    }
}