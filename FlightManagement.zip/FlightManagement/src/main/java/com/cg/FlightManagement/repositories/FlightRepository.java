package com.cg.FlightManagement.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.FlightManagement.entity.*;

public interface FlightRepository extends JpaRepository<Flight, Long> {
}
