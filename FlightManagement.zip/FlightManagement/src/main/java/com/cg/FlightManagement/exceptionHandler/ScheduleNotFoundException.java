package com.cg.FlightManagement.exceptionHandler;

public class ScheduleNotFoundException extends RuntimeException {
    public ScheduleNotFoundException(String msg) {
    	super(msg);
    }
}