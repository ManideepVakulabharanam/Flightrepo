package com.cg.FlightManagement.service;

import com.cg.FlightManagement.entity.*;
import com.cg.FlightManagement.exceptionHandler.CouldNotAddException;
import com.cg.FlightManagement.exceptionHandler.CouldNotFoundException;
import com.cg.FlightManagement.exceptionHandler.NoDataFoundException;
import com.cg.FlightManagement.repositories.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScheduleService {
    @Autowired
    private ScheduleRepository scheduleRepository;

    public Schedule addSchedule(Schedule schedule) {
    	Schedule existingRoute = scheduleRepository.findById(schedule.getId()).orElse(null);
    	if(existingRoute == null) {
    		 return scheduleRepository.save(schedule);
    	}
    	else{
    		throw new CouldNotAddException("Could not Add schedule, schedule aleardy exsists");
    	}
    }

    public List<Schedule> getAllSchedules() {
    	 List<Schedule> list = scheduleRepository.findAll();;
         if(list.size() == 0) {
         	throw new NoDataFoundException("No schedules were found.");
         }else {
         	return list;
         }
        
    }

    public void deleteSchedule(Long id) {
    	if(scheduleRepository.existsById(id)) {
    		scheduleRepository.deleteById(id);
       	}
       	else {
       		throw new CouldNotFoundException("We could not find the data by given ID. please enter valid ID");
       	}
    }
}

