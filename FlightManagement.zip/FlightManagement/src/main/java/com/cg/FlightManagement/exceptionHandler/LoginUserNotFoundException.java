package com.cg.FlightManagement.exceptionHandler;

public class LoginUserNotFoundException extends RuntimeException {
    public LoginUserNotFoundException(String msg) {
    	super(msg);
    }
}