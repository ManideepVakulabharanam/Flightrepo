package com.cg.FlightManagement.exceptionHandler;

public class NoFlightsFoundException extends RuntimeException {
    public NoFlightsFoundException(String msg) {
    	super(msg);
    }
}