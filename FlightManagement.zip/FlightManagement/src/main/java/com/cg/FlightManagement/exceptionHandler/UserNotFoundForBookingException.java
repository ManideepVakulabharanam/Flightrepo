package com.cg.FlightManagement.exceptionHandler;

public class UserNotFoundForBookingException extends RuntimeException {
    public UserNotFoundForBookingException(String msg) {
    	super(msg);
    }
}