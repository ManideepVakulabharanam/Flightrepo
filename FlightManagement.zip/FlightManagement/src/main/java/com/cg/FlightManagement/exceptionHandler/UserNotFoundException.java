package com.cg.FlightManagement.exceptionHandler;

public class UserNotFoundException extends RuntimeException {
    public UserNotFoundException(String msg) {
    	super(msg);
    }
}