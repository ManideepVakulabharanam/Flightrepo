package com.cg.FlightManagement.service;

import com.cg.FlightManagement.entity.*;
import com.cg.FlightManagement.exceptionHandler.CouldNotAddException;
import com.cg.FlightManagement.exceptionHandler.CouldNotFoundException;
import com.cg.FlightManagement.exceptionHandler.NoDataFoundException;
import com.cg.FlightManagement.repositories.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RouteService {
    @Autowired
    private RouteRepository routeRepository;

    public Route addRoute(Route route) {
    	Route existingRoute = routeRepository.findById(route.getId()).orElse(null);
    	if(existingRoute == null) {
    		 return routeRepository.save(route);
    	}
    	else{
    		throw new CouldNotAddException("Could not Add Route, Route aleardy exsists");
    	}
       
    }

    public List<Route> getAllRoutes() {
    	 List<Route> list = routeRepository.findAll();
         if(list.size() == 0) {
         	throw new NoDataFoundException("No Routes were found.");
         }else {
         	return list;
         }
        
    }

    public void deleteRoute(Long id) {
    	if(routeRepository.existsById(id)) {
    		 routeRepository.deleteById(id);
        	}
        	else {
        		throw new CouldNotFoundException("We could not find the data by given ID. please enter valid ID");
        	}
       
    }
}
