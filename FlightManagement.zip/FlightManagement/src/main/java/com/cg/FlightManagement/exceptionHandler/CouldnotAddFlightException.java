package com.cg.FlightManagement.exceptionHandler;

public class CouldnotAddFlightException extends RuntimeException {
    public CouldnotAddFlightException(String msg) {
    	super(msg);
    }
}
