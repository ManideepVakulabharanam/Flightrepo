package com.cg.FlightManagement.service;

import com.cg.FlightManagement.entity.*;
import com.cg.FlightManagement.exceptionHandler.UserAlreadyExistsException;
import com.cg.FlightManagement.exceptionHandler.UserNotFoundException;
import com.cg.FlightManagement.repositories.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public User createUser(User user) {
    	User existingUser = userRepository.findById(user.getId()).orElse(null);
    	if(existingUser == null) {
    		return userRepository.save(user);
    	}
    	else{
    		throw new UserAlreadyExistsException("Could not Add schedule, User aleardy exsists");
    	}
    }

    public User findByUsername(String username) {
    	User user = userRepository.findByUsername(username);
    	if(user == null) {
    		throw new UserNotFoundException("We could not find the data by given ID. please enter valid ID");
       	}
       	else {
       		return user;
       	}
    }
}
